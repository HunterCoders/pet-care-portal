import React from 'react';
import './Homepage.css';
import logo from './PetCareLogo.png'
import {Link} from 'react-router-dom';
function Homepage() {
  return (
    <div className="App">
      <header className="App-header">
      <img src={logo} alt="Welcome" style={{ width: '500px', height: '500px' }} />
      </header>
      <main>
        <section className="ImageSection">
            <div className='logoDiv' style={{backgroundColor:'white'}}>
            {/* <img src={logo} alt="Welcome" style={{ width: '200px', height: '200px' }} /> */}
            </div>
        </section>
        <section className="CardsSection">
          <div className="Card">
            <h2>Doctor</h2>
            <p>Explore our medical services</p>
            <button><Link to="/docRegister">Register</Link></button>
            <button><Link to="/docLogin">Login</Link></button>
          </div>
          <div className="Card">
            <h2>Customer</h2>
            <p>Find out about our customer services</p>
            <button><Link to="/cusRegister">Register</Link></button>
            <button><Link to="/cusLogin">Login</Link></button>
          </div>
          <div className="Card">
            <h2>Admin</h2>
            <p>Access admin features</p>
            <button><Link to="/adminOptions">Login</Link></button>
          </div>
        </section>
      </main>
      <footer>
        <p>&copy; 2024 Our Company</p>
      </footer>
    </div>
  );
}

export default Homepage;
